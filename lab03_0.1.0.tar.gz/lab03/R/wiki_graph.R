#'Graph including nodes and weight of each edge 
#'
#'Dataframe containing nodes and edge weight of a graph
#'
#'@format Dataframe with 18 rows and 3 variables
#'   \describe{
#'   \item1{v1} {beginning node}
#'   \item2{v2} {end node in the edge}
#'   \item3{w}  {weight of edge from v1 to v2}
#'   
#'   }
#'   @source \url{(https://en.wikipedia.org/wiki/Graph (mathematics)}
#'   

"wiki_graph"